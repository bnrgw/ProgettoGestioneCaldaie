export interface ResponseBackend {
    rc: boolean;
    msg: string | null;
    dati: any[];
  }