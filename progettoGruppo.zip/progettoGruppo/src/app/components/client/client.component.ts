import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule, MatCellDef, MatHeaderCellDef, MatRowDef, MatHeaderRowDef } from '@angular/material/table';
import { AuthService } from '../../services/auth/auth.service';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
@Component({
  selector: 'app-client',
  standalone: true,
  imports: [MatIconModule, MatMenuModule, MatTableModule, MatCellDef, MatHeaderCellDef, MatHeaderRowDef, MatRowDef, MatPaginatorModule, MatDialogModule, MatButtonModule, RouterModule, MatCardModule, CommonModule],
  templateUrl: './client.component.html',
  styleUrl: './client.component.css'
})
export class ClientComponent {
  constructor(private router: Router, private authService: AuthService){}
  goToBoilers() {
    this.router.navigate(['/client/boilers']);
  }
  goToTickets() {
    this.router.navigate(['/client/tickets']);
  }
  userLogout(){
    this.authService.logout();
    this.router.navigate([`/login`]);
  }
  
}
