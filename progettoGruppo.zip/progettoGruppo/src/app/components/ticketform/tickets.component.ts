import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MATERIAL_SANITY_CHECKS, MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox'; // Import MatCheckboxModule
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TicketService } from '../../services/ticket/ticket.service';

@Component({
  selector: 'app-tickets',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatInputModule, 
    MatButtonModule, 
    MatFormFieldModule, 
    MatSelectModule, 
    MatOptionModule, 
    MatDatepickerModule, 
    MatNativeDateModule, 
    HttpClientModule,
    MatCheckboxModule
  ],
  templateUrl: './tickets.component.html',
  styleUrls: ['./tickets.component.css']
})
export class TicketsComponent implements OnInit {
  ticketForm: FormGroup;
  public isUpdate = false;
  public tickets: any[] = [];
  public currentTicketId: number | null = null;

  daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  timesOfDay = ['09:00-13:00', '14:00-18:00'];

  constructor(
    private fb: FormBuilder, 
    private apiService: TicketService,
    public matDialogRef: MatDialogRef<TicketsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.ticketForm = this.fb.group({
      userId: [parseInt(this.data.clientId)],
      text: [''],
      preferredDate: this.fb.group({
        dates: [[]],
        times: [[]],
      }),
      response: [''],
      state: [false],
      evaluationId: [null],
    });

    if(data && data.id) {
      this.isUpdate = true;
      this.ticketForm.patchValue({
        response: data.response,
        state: data.state
      });
    }
  }

  ngOnInit(): void {

  }

  onSubmit() {
    if (this.ticketForm.valid) {
      const formValue = this.ticketForm.getRawValue();
      const { dates, times } = formValue.preferredDate;
      formValue.preferredDate = `${dates.join(', ')}, ${times.join(', ')}`;
      if (this.isUpdate && this.currentTicketId !== null) {
        this.matDialogRef.close(this.apiService.updateTicket(formValue).subscribe());
      } else {
        console.log('userid', this.data.clientId);
        this.matDialogRef.close(this.apiService.addTicket(formValue).subscribe());
      }
    } else {
      console.log('Form is invalid. Please check the errors.');
      console.log(this.ticketForm.errors);
    }

    
    this.resetForm();
  }


  resetForm() {
    this.ticketForm.reset();
  }
}
