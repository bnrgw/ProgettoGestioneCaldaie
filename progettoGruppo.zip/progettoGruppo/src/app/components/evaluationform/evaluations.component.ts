import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-evaluations',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatInputModule, 
    MatButtonModule, 
    MatFormFieldModule, 
    MatSelectModule, 
    MatOptionModule, 
    HttpClientModule
  ],
  templateUrl: './evaluations.component.html',
  styleUrl: './evaluations.component.css'
})
export class EvaluationsComponent implements OnInit {
  evaluationForm: FormGroup;
  public isClient: boolean = true;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.evaluationForm = this.fb.group({
      rating: ['', Validators.required],
      note: [''],
    });
  }

  async ngOnInit(): Promise<void> {
    const user = await this.getCurrentUser();
    this.checkUserRole(user);

    if(this.isClient) {
      const ticketId = await this.getTicketId();
      this.evaluationForm.patchValue({ idTicket: ticketId });
    }
  }

  checkUserRole(user: any) {
    if (user.role === 'client') {
      this.isClient = true;
    } 
  }

  async getCurrentUser(): Promise<any> {
    const url = 'https://your-backend-endpoint.com/api/current-user';
    try {
      const response: any = await lastValueFrom(this.http.get(url));
      return response;
    } catch (error) {
      console.error('Error fetching current user :(', error);
      return null;
    }
  }

  async getTicketId(): Promise<any> {
    const url = 'https://your-backend-endpoint.com/api/current-ticket';
    try {
      const response: any = await lastValueFrom(this.http.get(url));
      return response.idTicket;
    } catch (error) {
      console.error('Error fetching ticket id :(', error);
      return '';
    }
  }

  onSubmit() {
    if(this.evaluationForm.valid) {
      const evaluationData = this.evaluationForm.value;
      this.submitEvaluation(evaluationData);
    }
  }

  submitEvaluation(data: any) {
    const url = 'https://your-backend-endpoint.com/api/evaluation';
    this.http.post(url, data).subscribe({
      next: (response) => {+
        console.log('Evaluation submitted :)', response);
      }, error: (error) => {
        console.error('Error submitting evaluation :(', error);
      }
    });
  }
}
