import { Component, Input, OnInit } from '@angular/core';
import { TicketService } from '../../services/ticket/ticket.service';
import { MatDialog } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatCell, MatHeaderCell, MatRow, MatHeaderRow } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatButtonModule} from '@angular/material/button';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { TicketsComponent } from '../ticketform/tickets.component';
import { MatIcon } from '@angular/material/icon';
import { ResponseBackend } from '../../models/response.models';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService } from '../../services/auth/auth.service';
import { MatSortModule } from '@angular/material/sort';
import { EvaluationsComponent } from '../evaluationform/evaluations.component';
@Component({
  selector: 'app-ticket',
  standalone: true,
  imports: [MatSortModule, MatIcon, MatButtonModule, MatPaginatorModule, MatCardModule, MatHeaderRow, MatRow, MatSelectModule, MatCell, MatHeaderCell, CommonModule, MatTableModule],
  templateUrl: './ticketpage.component.html',
  styleUrl: './ticketpage.component.css'
})
export class TicketPageComponent implements OnInit{
  tickets: any[] = []; 
  isAdmin: boolean = false;
  clientId: number = 0;
  displayedColumns: string[] = [];
  noTicketsMessage: string = '';

  constructor(
    private snackBar: MatSnackBar,
    private ticketService: TicketService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    console.log('entro oninit ticket');

    this.isAdmin = this.authService.getRole() === 'admin';

    if (this.isAdmin) {
      this.route.paramMap.subscribe(params => {
        const clientIdParam = params.get('id');
        this.clientId = clientIdParam ? parseInt(clientIdParam, 10) : 0;
        console.log('Ticketpage clientId (admin) = ', this.clientId);
      });
    } else {
      this.clientId = this.authService.getId();
    }

    //carico gli interventi se il cliente è valido
    if (this.clientId === 0) {
      this.noTicketsMessage = 'client id non valido o non trovato.';
      return;
    }
    this.loadTickets();
  }

  backwards(){
    if(this.isAdmin) this.router.navigate(['/admin']);
    else if(!this.isAdmin){this.router.navigate(['/client']);}
    else this.router.navigate(['/login']);
  }

  loadTickets(): void {
    this.ticketService.getTicketsForClient(this.clientId!).subscribe(
      (response: ResponseBackend) => {
        console.log(response);
        if (response.rc) {
          if (Array.isArray(response.dati) && response.dati.length > 0) {
            console.log(response.dati);
            this.tickets = response.dati;
            if (this.isAdmin) {
              this.tickets.forEach(ticket => {
                ticket.actions = this.getDefaultActions();
              });
            }
            
            this.noTicketsMessage = '';
          } else {
            this.tickets = [];
            this.noTicketsMessage = 'No tickets found for this client.';
          }
        } else {
          this.tickets = [];
          this.noTicketsMessage = response.msg || 'Errore nel recupero dei ticket.';
        }
  
        this.displayedColumns = this.isAdmin 
          ? ['id', 'text', 'state', 'preferedDate', 'response', 'actions'] 
          : ['id', 'text', 'state', 'preferedDate', 'response',];
      },
      (error) => {
        console.error('Errore nel caricare i ticket:', error);
        this.noTicketsMessage = 'Errore nel recupero dei ticket.';
      }
    );
  }
  
  //aggiungi ticket
  onAddTicket(): void {
    const dialogRef = this.dialog.open(TicketsComponent, {
      data: {clientId: this.clientId}
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccessMessage('Ticket added successfully!');
        this.loadTickets();
      } else {
        this.showErrorMessage('Ticket addition cancelled or failed.');
      }
    });
  }

  //modifica ticket
  onEditTicket(ticket: any): void {
    const ticketToEdit = { ...ticket };
    delete ticketToEdit.actions;

    const ticketClean = {
      ...ticketToEdit,
      clientId: this.clientId
    };

    const dialogRef = this.dialog.open(TicketsComponent, {
      data: ticketClean
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const index = this.tickets.findIndex(t => t.id === result.id);
        if (index !== -1) {
          this.tickets[index] = result;
          this.loadTickets();
        }
        this.showSuccessMessage('Ticket updated successfully!');
      } else {
        this.showErrorMessage('Ticket update failed or cancelled.');
      }
    });
  }

  addValutation(ticketId: any){
    const dialogRef = this.dialog.open(EvaluationsComponent, {
      data: { ticketId: ticketId }
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccessMessage('Valutation added successfully!');
        this.loadTickets();
      } else {
        this.showErrorMessage('Valutation addition cancelled or failed.');
      }
    });
  }

  getDefaultActions(): any {
    if (this.isAdmin) return {edit: true};
    else return {add: true};
  }
  showSuccessMessage(msg: string | null): void {
    if (msg) {
      this.snackBar.open(msg, 'Chiudi', {
        duration: 3000,
        panelClass: ['success-snackbar']
      });
    }
  }
  
  showErrorMessage(msg: string | null): void {
    if (msg) {
      this.snackBar.open(msg, 'Chiudi', {
        duration: 3000,
        panelClass: ['error-snackbar']
      });
    }
  }
}



