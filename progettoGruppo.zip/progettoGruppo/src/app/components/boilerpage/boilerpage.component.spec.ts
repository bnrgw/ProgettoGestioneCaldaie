import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoilerPageComponent } from './boilerpage.component';

describe('BoilerComponent', () => {
  let component: BoilerPageComponent;
  let fixture: ComponentFixture<BoilerPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BoilerPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BoilerPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
