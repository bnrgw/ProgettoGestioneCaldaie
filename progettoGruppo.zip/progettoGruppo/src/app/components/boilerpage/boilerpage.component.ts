import { Component, OnInit } from '@angular/core';
import { BoilerService } from '../../services/boiler/boiler.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatCell, MatHeaderCell, MatRow, MatHeaderRow } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { BoilerModalComponent } from '../boilerform/boiler-modal.component';
import { Input } from '@angular/core';
import { ResponseBackend } from '../../models/response.models';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthService } from '../../services/auth/auth.service';
import { DateAdapter } from '@angular/material/core';

@Component({
  selector: 'app-boiler',
  standalone: true,
  imports: [MatButtonModule, MatDialogModule, MatIconModule, MatCardModule, MatPaginatorModule, MatCell, MatSelectModule, MatHeaderCell, MatRow, MatHeaderRow, RouterModule, CommonModule, MatTableModule],
  templateUrl: './boilerpage.component.html',
  styleUrl: './boilerpage.component.css'
})
export class BoilerPageComponent implements OnInit{
  boilers: any[] = [];
  isAdmin: boolean = false; 
  displayedColumns: string[] = [];
  clientId: number = 0;
  noBoilersMessage :string = '';


  constructor(
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router,
    private boilerService: BoilerService,
    private dialog: MatDialog, 
    private authService: AuthService
  ) {  }

  ngOnInit(): void {
    console.log('entro oninit boilerpage', this.boilers);

    this.isAdmin = this.authService.getRole() === "admin";

    if (this.isAdmin) {
      this.route.paramMap.subscribe(params => {
        const clientIdParam = params.get('id');
        this.clientId = clientIdParam ? parseInt(clientIdParam, 10) : 0;
        console.log('Boilerpage clientId (admin) = ', this.clientId);
      });
    } else {
      this.clientId = this.authService.getId();
    }

    //carico i boiler se il client è valido
    if (this.clientId === 0) {
      this.noBoilersMessage = 'client id non valido o non trovato.';
      return;
    }
    this.loadBoilers();
  }
  backwards(){
    if(this.isAdmin) this.router.navigate(['/admin']);
    else if(!this.isAdmin){this.router.navigate(['/client']);}
    else this.router.navigate(['/login']);
  }
  loadBoilers(): void {
    this.boilerService.getBoilersByClientId(this.clientId!).subscribe(
      (response: ResponseBackend) => {
        if(response.rc){
        if (Array.isArray(response.dati) && response.dati.length > 0) {
          this.boilers = response.dati;
          
          if (this.isAdmin) {
            this.boilers.forEach(boiler => {
              boiler.actions = this.getDefaultActions();
            });
          }
          
          this.noBoilersMessage = '';
        } else {
          this.boilers = [];
          this.noBoilersMessage = 'No boilers found for this client.';
        }
      }else{
        this.boilers = [];
        this.noBoilersMessage = response.msg || 'Errore nel recupero dei boiler.';
      }

        this.displayedColumns = this.isAdmin 
          ? ['id', 'brand', 'model', 'serialNumber', 'revisionDate', 'actions'] 
          : ['id', 'brand', 'model', 'serialNumber', 'revisionDate'];
      },
      (error) => {
        console.error('Errore nel caricare i boiler:', error);
        this.noBoilersMessage = 'Errore nel recupero dei boiler.';
      }
    );

  }
  
  //aggiungi boiler
  onAddBoiler(): void {
    const dialogRef = this.dialog.open(BoilerModalComponent, {
      data: this.clientId 
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccessMessage('Boiler added successfully!');
        this.loadBoilers();
      } else {
        this.showErrorMessage('Boiler addition cancelled or failed.');
      }
    });
  }

  //modifica boiler
  onEditBoiler(boiler: any): void {
    const boilerToEdit = { ...boiler };
    delete boilerToEdit.actions;

    const boilerClean = {
      ...boilerToEdit,
      clientId: this.clientId
    };

    const dialogRef = this.dialog.open(BoilerModalComponent, {
      data: boilerClean
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadBoilers();
        this.showSuccessMessage('Boiler updated successfully!');
      } else {
        this.showErrorMessage('Boiler update cancelled or failed.');
      }
    });
  }

  //cancella boiler
  onDeleteBoiler(boiler: any): void {
    if (confirm('Are you sure you want to delete this boiler?')) {
      const boilerToDelete = { ...boiler };
      delete boilerToDelete.actions;
  
      this.boilerService.deleteBoiler(boilerToDelete.id).subscribe({
        next: () => {
          this.loadBoilers();
          this.showSuccessMessage('Boiler deleted successfully!');
        },
        error: (error) => {
          console.error('Error deleting boiler:', error);
          this.showErrorMessage('Error deleting boiler. Please try again.');
        }
      });
    }
  }
  
  getDefaultActions(): any {
    return {
      edit: true,
      delete: true
    };
  }

  showSuccessMessage(msg: string | null): void {
    if (msg) {
      this.snackBar.open(msg, 'Chiudi', {
        duration: 3000,
        panelClass: ['success-snackbar']
      });
    }
  }
  
  showErrorMessage(msg: string | null): void {
    if (msg) {
      this.snackBar.open(msg, 'Chiudi', {
        duration: 3000,
        panelClass: ['error-snackbar']
      });
    }
  }
}
