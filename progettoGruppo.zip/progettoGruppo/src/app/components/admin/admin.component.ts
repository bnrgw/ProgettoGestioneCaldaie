import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import { AuthService } from '../../services/auth/auth.service';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { ClientService } from '../../services/client/client.service';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule, MatCellDef, MatHeaderCellDef, MatRowDef, MatHeaderRowDef, MatTableDataSource } from '@angular/material/table';
import { UsersComponent } from '../userform/users.component';
import { MatIconModule } from '@angular/material/icon';
import { BoilerService } from '../../services/boiler/boiler.service';
import { BoilerPageComponent } from '../boilerpage/boilerpage.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatSortModule, MatSort } from '@angular/material/sort';
import { MatLabel, MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ResponseBackend } from '../../models/response.models';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import {MatMenuModule} from '@angular/material/menu';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [MatSortModule, MatMenuModule, MatSnackBarModule, MatInputModule, MatFormFieldModule, MatLabel, MatExpansionModule, BoilerPageComponent, MatIconModule, CommonModule, MatButtonModule, MatDialogModule, MatPaginatorModule, MatTableModule, MatCellDef, MatHeaderCellDef, MatHeaderRowDef, MatRowDef],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit{
  userId :number = 0;
  clients : any[] = [];
  displayedColumns: string[] = ['id', 'name', 'surname', 'fiscal_code', 'address', 'cap', 'city', 'province', 'actions', 'boilers', 'tickets'];
  role : string | null = null;
  isAdmin :boolean = false;
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  
  constructor(private snackBar: MatSnackBar,private authService: AuthService, private dialog: MatDialog, 
    private clientService: ClientService, private boilerService: BoilerService, private route: Router) {
      this.dataSource = new MatTableDataSource(this.clients);

    }

  ngOnInit(): void {
    this.isAdmin = this.authService.getRole() === "admin";
    this.userId = this.authService.getId();

    console.log(this.isAdmin, this.authService.getRole(), this.userId);
    this.loadClients();
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  userLogout(){
    this.authService.logout();
    this.route.navigate([`/login`]);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  loadClients(): void {
    this.clientService.getClients().subscribe(
      (response: ResponseBackend) => {
        if (Array.isArray(response.dati)) {
          this.clients = response.dati.map(client => ({
            ...client,
            actions: this.getDefaultActions(client)
          }));          
          this.dataSource.data = this.clients;
        } else {
          console.error('La proprietà dati non è un array o non esiste:', response);
        }
      },
      error => {
        console.error('Errore nel caricare i client per l\'admin:', error);
      }
    );
  }

  //carica le caldaie di un cliente
  goToBoilersForClient(clientId: number): void {
    this.route.navigate([`/admin/boilers/`+clientId]);
  }

  //carica gli interventi di un cliente
  goToTicketsForClient(clientId: number): void {
    this.route.navigate([`/admin/tickets/`+clientId]);
  }
  
//aggiungi client
onAddClient(): void {
  const dialogRef = this.dialog.open(UsersComponent);

  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      const newClient = result;
      
      this.clientService.addClient(newClient).subscribe({
        next: (response: ResponseBackend) => {
          if (response.rc) {
            this.loadClients();
            this.showSuccessMessage(response.msg);
          } else {
            this.showErrorMessage(response.msg);
          }
        },
        error: () => {
          this.showErrorMessage('Si è verificato un errore durante l\'aggiunta del cliente.');
        }
      });
    }
  });
}
showSuccessMessage(msg: string | null): void {
  if (msg) {
    this.snackBar.open(msg, 'Chiudi', {
      duration: 3000,
      panelClass: ['success-snackbar']
    });
  }
}

showErrorMessage(msg: string | null): void {
  if (msg) {
    this.snackBar.open(msg, 'Chiudi', {
      duration: 3000,
      panelClass: ['error-snackbar']
    });
  }
}

  getDefaultActions(client: any): any {
    return {
      edit: true,
      delete: true
    };
  }

  //modifica client
  /*onEditClient(client: any): void {
    const dialogRef = this.dialog.open(UsersComponent, {
      data: {client, isUpdate: true}
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadClients();
      }
    });
  }*/

    onEditClient(client: any): void {
      const clientToEdit = { ...client };
      delete clientToEdit.actions;
        
      const dialogRef = this.dialog.open(UsersComponent, {
        data: clientToEdit
      });
    
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.loadClients();
          this.showSuccessMessage('Client updated successfully!');
        } else {
          this.showErrorMessage('Client update failed or cancelled.');
        }
      });
    }

  //cancella client
  onDeleteClient(client: any): void {
    this.clientService.deleteClient(client).subscribe({
      next: (response: ResponseBackend) => {
        if (response.rc) {
          this.loadClients();
          this.showSuccessMessage(response.msg);
        } else {
          this.showErrorMessage(response.msg);
        }
      },
      error: () => {
        this.showErrorMessage('Si è verificato un errore durante la cancellazione del cliente.');
      }
    });
  }

}
