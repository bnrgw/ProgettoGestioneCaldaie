import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ClientService } from '../../services/client/client.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatInputModule, 
    MatButtonModule, 
    MatFormFieldModule, 
    MatSelectModule, 
    MatOptionModule, 
    HttpClientModule, 
    MatCheckboxModule
  ],
  templateUrl: './users.component.html',
  styleUrl: './users.component.css'
})
export class UsersComponent implements OnInit {
  userForm: FormGroup;
  public isAdmin = false;
  public isUpdate = false;
  roles = ['admin', 'client'];

  constructor(private fb: FormBuilder, 
    private apiService: ClientService, 
    private matDialogRef: MatDialogRef<ClientService>,
    private matDialogref: MatDialogRef<UsersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.userForm = this.fb.group({
      id: [{ value: '', disabled: true }], 
      name: ['', Validators.required], 
      surname: ['', Validators.required], 
      cf: ['', [Validators.required, Validators.pattern('[A-Z0-9]+')]], 
      address: [''], 
      cap: [''], 
      city: [''], 
      province: [''], 
      role: ['', Validators.required]
    });
  }

  async ngOnInit(): Promise<void> {
    const userLogged = this.data;
    if(userLogged) {
      this.isUpdate = true;
      this.fetchUserData(userLogged);
    }
  }

  fetchUserData(user: any) {
      
            this.userForm.patchValue({
              name: user.name,
              surname: user.surname,
              cf: user.cf,
              address: user.address,
              cap: user.cap,
              city: user.city,
              province: user.province,
              role: user.role
            });
  }

  onSubmit() {
    console.log('form valid: ', this.userForm.valid);
    console.log('form value: ', this.userForm.value);
      if(this.userForm.valid) {
        const formValue = this.userForm.getRawValue();
        if(this.isUpdate) {
          this.matDialogRef.close(this.apiService.updateClient(formValue).subscribe());
        } else {
          this.matDialogRef.close(this.apiService.addClient(formValue).subscribe());
        }
      } else {
        console.error('Invalid form: ', this.userForm.errors);
      }
  }

}
