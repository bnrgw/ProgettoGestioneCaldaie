import {Component, OnInit} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth/auth.service';
import { Router, RouterModule } from '@angular/router';
import {MatCardModule} from '@angular/material/card';
import { MatFormFieldModule, MatError, MatLabel } from '@angular/material/form-field';
import { MatSelectModule, MatOption } from '@angular/material/select';
import { CommonModule } from '@angular/common';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [MatButtonModule, MatInputModule, CommonModule, MatOption, MatSelectModule, MatError, MatLabel, RouterModule, ReactiveFormsModule, MatFormFieldModule, MatCardModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  errorMsg= "";
  loginForm: FormGroup;

  constructor(private authService: AuthService, private router: Router, private fb: FormBuilder){ 
    this.loginForm = this.fb.group({
      fiscal_code: ['', Validators.required],
      role: ['', Validators.required],
      psw: ['', Validators.required]
    });
  }

  getFiscal_code(){
    return this.loginForm.controls['fiscal_code'].value;
  }
  getRole(){
    return this.loginForm.controls['role'].value;
  }
  getPsw(){
    return this.loginForm.controls['psw'].value;
  }

  doLogin(): void {
    if (this.loginForm.invalid) {
      this.errorMsg = 'Compila correttamente tutti i campi.';
      return;
    }

    const { fiscal_code, role, psw } = this.loginForm.value;

    this.authService.login(fiscal_code, role, psw).subscribe(
      (response) => {
        this.authService.setUserSession(response);
        if (role === 'admin') {
          console.log(fiscal_code, role, psw);
          this.router.navigate(['/admin']);
        } else if (role === 'client') {
          console.log(fiscal_code, role, psw);
          this.router.navigate(['/client']);
        }
      },
      (error) => {
        this.errorMsg = error;
      }
    );
  }
  
  ngOnInit(): void {  }
}
