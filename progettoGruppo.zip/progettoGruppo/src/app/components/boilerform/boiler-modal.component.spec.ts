import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoilerModalComponent } from './boiler-modal.component';

describe('BoilerModalComponent', () => {
  let component: BoilerModalComponent;
  let fixture: ComponentFixture<BoilerModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BoilerModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BoilerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
