import { Component, Inject, model, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, provideNativeDateAdapter } from '@angular/material/core';
import { HttpClient, HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { BoilerService } from '../../services/boiler/boiler.service';

@Component({
  selector: 'app-boiler-modal',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    HttpClientModule
  ],
  templateUrl: './boiler-modal.component.html',
  styleUrls: ['./boiler-modal.component.css'],
  providers: [DatePipe, provideNativeDateAdapter()]
})
export class BoilerModalComponent implements OnInit {
  boilerForm: FormGroup;
  private isUpdate = false;
  private currentBoilerId: number | null = null;

  constructor(
    private fb: FormBuilder, 
    private http: HttpClient, 
    private datePipe: DatePipe,
    private apiService : BoilerService,
    private matDialogRef: MatDialogRef<BoilerModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.boilerForm = this.fb.group({
      userId: ['', Validators.required],
      brand: ['', Validators.required],
      model: ['', Validators.required],
      serialNumber: ['', Validators.required],
      revisionDate: ['', Validators.required]
    });

    if(data && data.brand) {
      this.isUpdate = true;
      this.currentBoilerId = data.id;


      const [month, day, year] = data.revisionDate.split('/');
      const formattedDate = `${year}-${month}-${day}`;

      this.boilerForm.patchValue({
        userId: parseInt(data.userId),
        brand: data.brand,
        model: data.model,
        serialNumber: data.serialNumber,
        revisionDate: formattedDate
      });
    }else{
      this.boilerForm.patchValue({
        userId: data
      });
    }
  }

  ngOnInit(): void {
      
  }

  fetchBoilerData(boiler: any): void {
    this.boilerForm.setValue({
            idUser: boiler.idUser || '',
            brand: boiler.brand || '',
            model: boiler.model || '',
            serialNumber: boiler.serialNumber || '',
            revisionDate: boiler.revisionDate ? new Date(boiler.revisionDate.split('-').reverse().join('-')) : ''
          });
        }


  onSubmit() {
    if (this.boilerForm.valid) {
      const formValue = this.boilerForm.getRawValue();
      formValue.revisionDate = this.datePipe.transform(formValue.revisionDate, 'dd-MM-yyyy');
      if(this.isUpdate && this.currentBoilerId !== null) {
        this.matDialogRef.close(this.apiService.updateBoiler(formValue).subscribe());
      } else {
        console.log(formValue);
        this.matDialogRef.close(this.apiService.addBoiler(formValue).subscribe());
      }
    } else {
      console.log('Form is invalid. Please check the errors.');
      console.log(this.boilerForm.errors);
    }
    this.boilerForm.reset();
  }

}
