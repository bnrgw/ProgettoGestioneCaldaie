import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth/auth.service';
import { Router } from '@angular/router';
@Injectable({
  providedIn: "root"
})

export class AuthGuard implements CanActivate {

  constructor(private authService: AuthService, private router: Router) {}

  /*canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const currentUser = this.authService.currentUserValue;
    if (currentUser && currentUser.roles === route.data.role) {
      return true;
    }
    this.router.navigate(['/login']);
    return false;
  }*/

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
      const role = this.authService.getRole();
      
        const expectedRole = route.data['role'];
        if (role  === expectedRole) {
          return true;
        } else {
          this.router.navigate(['/login']);
          return false;
        }
      
  
      this.router.navigate(['/login']);
      return false;
    }
}

