import { Routes } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
import { ClientComponent } from './components/client/client.component';
import { LoginComponent } from './components/login/login.component'; 
import { AuthGuard } from './guards/auth.guard';
import { TicketPageComponent } from './components/ticketpage/ticketpage.component';
import { BoilerPageComponent } from './components/boilerpage/boilerpage.component';

export const routes: Routes = [
  { path: `admin`, component: AdminComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: `admin/tickets/:id`, component: TicketPageComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: `admin/boilers/:id`, component: BoilerPageComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: `client`, component: ClientComponent, canActivate: [AuthGuard], data: { role: 'client' } },
  { path: `client/tickets`, component: TicketPageComponent, canActivate: [AuthGuard], data: { role: 'client' }},
  { path: `client/boilers`, component: BoilerPageComponent, canActivate: [AuthGuard], data: { role: 'client' }},
  { path: ``, redirectTo: '/login', pathMatch: 'full' },
  { path: `login`, component: LoginComponent }

];
