import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { ResponseBackend } from '../../models/response.models';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private apiUrl = 'http://localhost:9090/rest/user';

  constructor(private http: HttpClient) { }
  /*getClientsForAdmin(): Observable<any[]> {
    const mockClients = [
      { id: 1, name: 'Mario', surname: 'Rossi', fiscal_code: 'RSSMRA80A01H501Z', address: 'Via Roma 1', boilers: [] },
      { id: 2, name: 'Luigi', surname: 'Verdi', fiscal_code: 'VRDLSG90B01F205Y', address: 'Via Milano 10' },
      { id: 3, name: 'Anna', surname: 'Bianchi', fiscal_code: 'BNCNNA85C41L219R', address: 'Via Torino 5'},
      { id: 4, name: 'Mario', surname: 'Rossi', fiscal_code: 'RSSMRA80A01H501Z', address: 'Via Roma 1', boilers: [] },
      { id: 5, name: 'Luigi', surname: 'Verdi', fiscal_code: 'VRDLSG90B01F205Y', address: 'Via Milano 10' },
      { id: 6, name: 'Anna', surname: 'Bianchi', fiscal_code: 'BNCNNA85C41L219R', address: 'Via Torino 5'},
      { id: 7, name: 'Anna', surname: 'Bianchi', fiscal_code: 'BNCNNA85C41L219R', address: 'Via Torino 5'},
      { id: 8, name: 'Mario', surname: 'Rossi', fiscal_code: 'RSSMRA80A01H501Z', address: 'Via Roma 1', boilers: [] },
      { id: 9, name: 'Luigi', surname: 'Verdi', fiscal_code: 'VRDLSG90B01F205Y', address: 'Via Milano 10' },
      { id: 10, name: 'Anna', surname: 'Bianchi', fiscal_code: 'BNCNNA85C41L219R', address: 'Via Torino 5'},
      { id: 11, name: 'Luigi', surname: 'Verdi', fiscal_code: 'VRDLSG90B01F205Y', address: 'Via Milano 10' },
      { id: 12, name: 'Anna', surname: 'Bianchi', fiscal_code: 'BNCNNA85C41L219R', address: 'Via Torino 5'}
    ];

    return of(mockClients);  
  }

  getClientForClient(clientId: number): Observable<any> {
    const mockClient = {
      id: clientId,
      name: 'Giovanni',
      surname: 'Verdi',
      fiscal_code: 'VRDGNN90X01F205X',
      address: 'Via Napoli 15',
      province: 'province1',
      city: "citta1",
      cap: 'cap1',
      role: "client"
    };

    return of(mockClient);
  }

  deleteClient(id: number): Observable<void> {
    return of();
  }*/

  getClients(): Observable<ResponseBackend> {
    return this.http.get<ResponseBackend>(`${this.apiUrl}/read`);
  }

  addClient(client: any): Observable<ResponseBackend> {
    return this.http.post<ResponseBackend>(`${this.apiUrl}/create`, client);
  }

  updateClient(client: any): Observable<ResponseBackend> {
    return this.http.put<ResponseBackend>(`${this.apiUrl}/update`, client);
  }

  deleteClient(client: any): Observable<ResponseBackend> {
    return this.http.delete<ResponseBackend>(`${this.apiUrl}/delete`, {body: client});
  }
}
