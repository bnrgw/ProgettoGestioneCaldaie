import { Injectable } from '@angular/core';
import { BehaviorSubject, map } from 'rxjs';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router, ActivatedRouteSnapshot } from '@angular/router';
import { ResponseBackend } from '../../models/response.models';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<any> = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser') || '{}'));
  public currentUser = this.currentUserSubject.asObservable();

  private fakeUsers = [
    {
      id: 1,
      fiscal_code: 'cf_admin',
      role: 'admin',
      name: 'Admin User',
      surname: 'Doe',
      address: '123 Admin St',
      cap: "cap1",
      city: 'Admin City',
      province: "province1",
      psw: 'admin123'
    },
    {
      id: 4,
      fiscal_code: 'cf_client',
      role: 'client',
      name: 'Client User',
      surname: 'Smith',
      address: '123 Client St',
      cap: "cap2",
      city: 'Client City',
      province: "province2",
      psw: 'client123'
    }
  ];

  constructor(private router: Router,private http: HttpClient) {}
  
  login(fiscal_code: string, role:string, psw: string) {
    return new Observable(observer => {
      this.http.post<any>('http://localhost:9090/rest/user/login', { fiscaleCode: fiscal_code, role, password: psw }).subscribe(
        userId => {
  
          if (userId) {
            localStorage.setItem('currentUser', JSON.stringify({ id: userId, fiscal_code, role }));
            localStorage.setItem('role', role);
            localStorage.setItem('id', userId);
            localStorage.setItem('fiscal_code', fiscal_code);
  
            //notifico il subject che l'utente c'è
            this.currentUserSubject.next({ id: userId, fiscal_code, role });
  
            observer.next({ id: userId });
            observer.complete();
          } else {
            observer.error('Credenziali non valide');
          }
        },
        error => {
          observer.error('Errore di connessione o server non disponibile');
        }
      );
    });
  }

    getRole(): string {
      const role = localStorage.getItem('role');
      return role ? role : ''; 
    }
    getId(): number {
      const id = localStorage.getItem('id');
      return id ? parseInt(id, 10) : 0;
    }

    /*login(fiscal_code: string, role: string, psw: string) {
      return new Observable(observer => {
        const user = this.fakeUsers.find(u => u.fiscal_code === fiscal_code && u.role === role && u.psw === psw);
    
        if (user) {
          localStorage.setItem('currentUser', JSON.stringify(user));
          localStorage.setItem('role', role);
          localStorage.setItem('id', user.id.toString());
          this.currentUserSubject.next(user);
          observer.next(user);
          observer.complete();
        } else {
          observer.error('Credenziali non valide');
        }
      });
    }*/

    logout() {
      localStorage.removeItem('currentUser');
      localStorage.removeItem('role');
      localStorage.removeItem('id');
      this.currentUserSubject.next(null);
    }
  
    get currentUserValue() {
      return this.currentUserSubject.value;
    }
  
    setUserSession(user: any) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      this.currentUserSubject.next(user);
    }

    getRoleFromPath(): string | null {
      const routeSnapshot = this.getRouteSnapshot(this.router.routerState.snapshot.root);
      return routeSnapshot?.data?.['role'] || null;
    }

    getRouteSnapshot(route: ActivatedRouteSnapshot): ActivatedRouteSnapshot | null {
      if (route.data && route.data['role']) {
        return route;
      }
  
      if (route.firstChild) {
        return this.getRouteSnapshot(route.firstChild);
      }
  
      return null;
    }

    getIdFromFiscalCode(fiscal_code: string) :Observable<ResponseBackend>{
      return this.http.get<ResponseBackend>(`http://localhost:9090/rest/user/?id=${fiscal_code}`);
    }
}
