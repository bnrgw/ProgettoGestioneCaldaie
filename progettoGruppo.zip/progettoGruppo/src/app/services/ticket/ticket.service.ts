import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, of, switchMap } from 'rxjs';
import { ResponseBackend } from '../../models/response.models';


@Injectable({
  providedIn: 'root'
})
export class TicketService {
  private apiUrl = 'http://localhost:9090/rest/ticket';

  constructor(private http: HttpClient) {}

  getTicketsForClient(clientId: number): Observable<ResponseBackend> {
    return this.http.get<ResponseBackend>(`http://localhost:9090/rest/user/readTickets?id=${clientId}`);
  }

  addEvaluation(evaluation: any): Observable<ResponseBackend> {
    return this.http.post<ResponseBackend>(`http://localhost:9090/rest/evaluation/create`, evaluation);
  }

  addTicket(ticket: any): Observable<ResponseBackend> {
    console.log('entro in add ticket', ticket);
    return this.http.post<ResponseBackend>(`${this.apiUrl}/create`, {body: ticket, observe: 'body'});
  }

  updateTicket(ticket: any): Observable<ResponseBackend> {
    return this.http.put<ResponseBackend>(`${this.apiUrl}/update`, {body: ticket, observe: 'body'});
  }

  deleteTicket(ticket: any): Observable<ResponseBackend> {
    return this.http.delete<ResponseBackend>(`${this.apiUrl}/delete`, {body: ticket, observe: 'body'});
  }

  /*getOpenTicketsForAdmin(): Observable<any[]> {
    return of([
      { id: 1, text: 'Descrizione del ticket admin 1', response: "r1", state: false },
      { id: 2, text: 'Descrizione del ticket admin 2' }
    ]);
  }

  getTicketsForClient(clientId: number): Observable<any[]> {
    return of([
      { id: 1, title: 'Ticket Client 1', description: 'Descrizione del ticket client 1' }
    ]);
  }*/
}
