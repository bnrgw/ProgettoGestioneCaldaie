import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, of, switchMap } from 'rxjs';
import { ResponseBackend } from '../../models/response.models';
/*export interface Boiler {
    id: number;
    brand: string;
    model: string;
    serialNumber: number;
    revisionDate: Date;
}*/

@Injectable({
  providedIn: 'root'
})
export class BoilerService {

  private apiUrl = 'http://localhost:9090/rest/boiler';

  constructor(private http: HttpClient) {}

  getBoilersByClientId(clientId: number): Observable<ResponseBackend> {
    console.log(`http://localhost:9090/rest/user/readBoilers?id=${clientId}`);
    return this.http.get<ResponseBackend>(`http://localhost:9090/rest/user/readBoilers?id=${clientId}`);
  }
  
  addBoiler(boiler: any): Observable<ResponseBackend> {
    console.log('aggiunta boiler');
    return this.http.post<ResponseBackend>(`${this.apiUrl}/create`, boiler);
  }

  updateBoiler(boiler: any): Observable<ResponseBackend> {
    return this.http.put<ResponseBackend>(`${this.apiUrl}/update`, boiler);
  }

  deleteBoiler(boiler: any): Observable<ResponseBackend> {
    return this.http.delete<ResponseBackend>(`${this.apiUrl}/delete`, {body: boiler, observe: 'body'});
  }
  
    /*getBoilersForClient(clientId: number): Observable<any[]> {
      return of([
        { id: 1, brand: 'Brand C', model: 'Model Z' },
        { id: 1, brand: 'Brand D', model: 'Model A' }
      ]);
      
    }
  
    deleteBoiler(id: number): Observable<void> {
      return of();
    }*/
}
