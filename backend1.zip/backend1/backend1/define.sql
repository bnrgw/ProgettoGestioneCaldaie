
    create table boiler (
        id integer not null auto_increment,
        revision_date date,
        serial_number integer,
        user_id integer,
        brand varchar(255),
        model varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table evaluation (
        id integer not null auto_increment,
        rating integer,
        ticket_id integer,
        note varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table ticket (
        id integer not null auto_increment,
        state bit,
        user_id integer,
        preferred_date varchar(255),
        response varchar(255),
        text varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
        id integer not null auto_increment,
        role tinyint,
        address varchar(255),
        cap varchar(255),
        city varchar(255),
        fiscal_code varchar(255),
        name varchar(255),
        password varchar(255),
        province varchar(255),
        surname varchar(255),
        primary key (id)
    ) engine=InnoDB;

    alter table evaluation 
       add constraint UK2ugtui1gqg4ygv1htnb5xhfjx unique (ticket_id);

    alter table users 
       add constraint UK5ylqtt3yi64npchv2v675kcx9 unique (fiscal_code);

    alter table boiler 
       add constraint FK8lqyer71mdyxf8eido7d334j4 
       foreign key (user_id) 
       references users (id);

    alter table evaluation 
       add constraint FKav753aad2jduc5yswjob1kf9 
       foreign key (ticket_id) 
       references ticket (id);

    alter table ticket 
       add constraint FKmvugyjf7b45u0juyue7k3pct0 
       foreign key (user_id) 
       references users (id);

    create table boiler (
        id integer not null auto_increment,
        revision_date date,
        serial_number integer,
        user_id integer,
        brand varchar(255),
        model varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table evaluation (
        id integer not null auto_increment,
        rating integer,
        ticket_id integer,
        note varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table ticket (
        id integer not null auto_increment,
        state bit,
        user_id integer,
        preferred_date varchar(255),
        response varchar(255),
        text varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
        id integer not null auto_increment,
        role tinyint,
        address varchar(255),
        cap varchar(255),
        city varchar(255),
        fiscal_code varchar(255),
        name varchar(255),
        password varchar(255),
        province varchar(255),
        surname varchar(255),
        primary key (id)
    ) engine=InnoDB;

    alter table evaluation 
       add constraint UK2ugtui1gqg4ygv1htnb5xhfjx unique (ticket_id);

    alter table users 
       add constraint UK5ylqtt3yi64npchv2v675kcx9 unique (fiscal_code);

    alter table boiler 
       add constraint FK8lqyer71mdyxf8eido7d334j4 
       foreign key (user_id) 
       references users (id);

    alter table evaluation 
       add constraint FKav753aad2jduc5yswjob1kf9 
       foreign key (ticket_id) 
       references ticket (id);

    alter table ticket 
       add constraint FKmvugyjf7b45u0juyue7k3pct0 
       foreign key (user_id) 
       references users (id);

    create table boiler (
        id integer not null auto_increment,
        revision_date date,
        serial_number integer,
        user_id integer,
        brand varchar(255),
        model varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table evaluation (
        id integer not null auto_increment,
        rating integer,
        ticket_id integer,
        note varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table ticket (
        id integer not null auto_increment,
        state bit,
        user_id integer,
        preferred_date varchar(255),
        response varchar(255),
        text varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
        id integer not null auto_increment,
        role tinyint,
        address varchar(255),
        cap varchar(255),
        city varchar(255),
        fiscal_code varchar(255),
        name varchar(255),
        password varchar(255),
        province varchar(255),
        surname varchar(255),
        primary key (id)
    ) engine=InnoDB;

    alter table evaluation 
       add constraint UK2ugtui1gqg4ygv1htnb5xhfjx unique (ticket_id);

    alter table users 
       add constraint UK5ylqtt3yi64npchv2v675kcx9 unique (fiscal_code);

    alter table boiler 
       add constraint FK8lqyer71mdyxf8eido7d334j4 
       foreign key (user_id) 
       references users (id);

    alter table evaluation 
       add constraint FKav753aad2jduc5yswjob1kf9 
       foreign key (ticket_id) 
       references ticket (id);

    alter table ticket 
       add constraint FKmvugyjf7b45u0juyue7k3pct0 
       foreign key (user_id) 
       references users (id);

    create table boiler (
        id integer not null auto_increment,
        revision_date date,
        serial_number integer,
        user_id integer,
        brand varchar(255),
        model varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table evaluation (
        id integer not null auto_increment,
        rating integer,
        ticket_id integer,
        note varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table ticket (
        id integer not null auto_increment,
        state bit,
        user_id integer,
        preferred_date varchar(255),
        response varchar(255),
        text varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
        id integer not null auto_increment,
        role tinyint,
        address varchar(255),
        cap varchar(255),
        city varchar(255),
        fiscal_code varchar(255),
        name varchar(255),
        password varchar(255),
        province varchar(255),
        surname varchar(255),
        primary key (id)
    ) engine=InnoDB;

    alter table evaluation 
       add constraint UK2ugtui1gqg4ygv1htnb5xhfjx unique (ticket_id);

    alter table users 
       add constraint UK5ylqtt3yi64npchv2v675kcx9 unique (fiscal_code);

    alter table boiler 
       add constraint FK8lqyer71mdyxf8eido7d334j4 
       foreign key (user_id) 
       references users (id);

    alter table evaluation 
       add constraint FKav753aad2jduc5yswjob1kf9 
       foreign key (ticket_id) 
       references ticket (id);

    alter table ticket 
       add constraint FKmvugyjf7b45u0juyue7k3pct0 
       foreign key (user_id) 
       references users (id);

    create table boiler (
        id integer not null auto_increment,
        revision_date date,
        serial_number integer,
        user_id integer,
        brand varchar(255),
        model varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table evaluation (
        id integer not null auto_increment,
        rating integer,
        ticket_id integer,
        note varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table ticket (
        id integer not null auto_increment,
        state bit,
        user_id integer,
        preferred_date varchar(255),
        response varchar(255),
        text varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table users (
        id integer not null auto_increment,
        role tinyint,
        address varchar(255),
        cap varchar(255),
        city varchar(255),
        fiscal_code varchar(255),
        name varchar(255),
        password varchar(255),
        province varchar(255),
        surname varchar(255),
        primary key (id)
    ) engine=InnoDB;

    alter table evaluation 
       add constraint UK2ugtui1gqg4ygv1htnb5xhfjx unique (ticket_id);

    alter table users 
       add constraint UK5ylqtt3yi64npchv2v675kcx9 unique (fiscal_code);

    alter table boiler 
       add constraint FK8lqyer71mdyxf8eido7d334j4 
       foreign key (user_id) 
       references users (id);

    alter table evaluation 
       add constraint FKav753aad2jduc5yswjob1kf9 
       foreign key (ticket_id) 
       references ticket (id);

    alter table ticket 
       add constraint FKmvugyjf7b45u0juyue7k3pct0 
       foreign key (user_id) 
       references users (id);
