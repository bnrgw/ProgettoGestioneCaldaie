
    alter table boiler 
       drop 
       foreign key FK8lqyer71mdyxf8eido7d334j4;

    alter table evaluation 
       drop 
       foreign key FKav753aad2jduc5yswjob1kf9;

    alter table ticket 
       drop 
       foreign key FKmvugyjf7b45u0juyue7k3pct0;

    drop table if exists boiler;

    drop table if exists evaluation;

    drop table if exists ticket;

    drop table if exists users;

    alter table boiler 
       drop 
       foreign key FK8lqyer71mdyxf8eido7d334j4;

    alter table evaluation 
       drop 
       foreign key FKav753aad2jduc5yswjob1kf9;

    alter table ticket 
       drop 
       foreign key FKmvugyjf7b45u0juyue7k3pct0;

    drop table if exists boiler;

    drop table if exists evaluation;

    drop table if exists ticket;

    drop table if exists users;

    alter table boiler 
       drop 
       foreign key FK8lqyer71mdyxf8eido7d334j4;

    alter table evaluation 
       drop 
       foreign key FKav753aad2jduc5yswjob1kf9;

    alter table ticket 
       drop 
       foreign key FKmvugyjf7b45u0juyue7k3pct0;

    drop table if exists boiler;

    drop table if exists evaluation;

    drop table if exists ticket;

    drop table if exists users;

    alter table boiler 
       drop 
       foreign key FK8lqyer71mdyxf8eido7d334j4;

    alter table evaluation 
       drop 
       foreign key FKav753aad2jduc5yswjob1kf9;

    alter table ticket 
       drop 
       foreign key FKmvugyjf7b45u0juyue7k3pct0;

    drop table if exists boiler;

    drop table if exists evaluation;

    drop table if exists ticket;

    drop table if exists users;

    alter table boiler 
       drop 
       foreign key FK8lqyer71mdyxf8eido7d334j4;

    alter table evaluation 
       drop 
       foreign key FKav753aad2jduc5yswjob1kf9;

    alter table ticket 
       drop 
       foreign key FKmvugyjf7b45u0juyue7k3pct0;

    drop table if exists boiler;

    drop table if exists evaluation;

    drop table if exists ticket;

    drop table if exists users;
