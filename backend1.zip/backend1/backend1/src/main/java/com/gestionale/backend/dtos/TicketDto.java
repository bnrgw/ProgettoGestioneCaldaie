package com.gestionale.backend.dtos;

public class TicketDto {
	private Integer id;
	private Integer userId;
	private String text;
	private String response;
	private Boolean state;
	private Integer evaluationId;
	private String preferredDate;

    

	public TicketDto(Integer id, Integer userId, String text, String response, Boolean state, Integer evaluationId,
			String referredDate) {
		super();
		this.id = id;
		this.userId = userId;
		this.text = text;
		this.response = response;
		this.state = state;
		this.evaluationId = evaluationId;
		this.preferredDate = referredDate;
	}
	
	

	public TicketDto(Integer id, Integer userId, String text, String response, Boolean state, String preferredDate) {
		super();
		this.id = id;
		this.userId = userId;
		this.text = text;
		this.response = response;
		this.state = state;
		this.preferredDate = preferredDate;
	}

  

	public TicketDto() {
		super();
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}


	public String getPreferredDate() {
		return preferredDate;
	}

	public void setPreferredDate(String preferredDate) {
		this.preferredDate = preferredDate;
	}

	public Boolean getState() {
		return state;
	}

	public void setState(Boolean state) {
		this.state = state;
	}

	public Integer getEvaluationId() {
		return evaluationId;
	}

	public void setEvaluationId(Integer evaluationId) {
		this.evaluationId = evaluationId;
	}

	

}
