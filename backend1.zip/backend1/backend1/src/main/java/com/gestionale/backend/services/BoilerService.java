package com.gestionale.backend.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionale.backend.dtos.BoilerDto;
import com.gestionale.backend.entities.Boiler;
import com.gestionale.backend.entities.User;
import com.gestionale.backend.repositories.BoilerRepository;
import com.gestionale.backend.repositories.UserRepository;


@Service
public class BoilerService {
	@Autowired 
	BoilerRepository boilerRepo;
	
	@Autowired 
	UserRepository userRepo;
	
	 private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	 
	 private static final Logger logger = LoggerFactory.getLogger(BoilerService.class);
	
	@Transactional
	public void createBoiler(BoilerDto boiler) throws Exception {
		
		Optional<User> user = userRepo.findById(boiler.getUserId());
		if(user.isEmpty()) {
			throw new Exception("Boiler's user does not exist");
		}
		
		if(user.get().getRole().toString() != "CLIENT") {
			throw new Exception("Boiler's user is not a client");
		}
		
		Boiler bo = new Boiler();
		bo.setBrand(boiler.getBrand());
		bo.setModel(boiler.getModel());
		bo.setSerialNumber(boiler.getSerialNumber());
		bo.setUser(user.get());
		bo.setRevisionDate(LocalDate.parse(boiler.getRevisionDate(), DATE_FORMATTER));
		
		try {
			boilerRepo.save(bo);
		} catch (Exception e) {
			throw new Exception("Error in boiler creation");
		}
	}
	
	
	public List<BoilerDto> readBoiler(){
		List<Boiler> resp = boilerRepo.findAll();
		
		return resp.stream()
				.map(u -> new BoilerDto(
						u.getId(),
						u.getUser().getId(),
						u.getBrand(),
						u.getModel(),
						u.getSerialNumber(),
						u.getRevisionDate().toString()
						))
				.collect(Collectors.toList());
	}
	
	
	@Transactional(rollbackFor = Exception.class)
	public void updateBoiler(BoilerDto boiler)throws Exception {
		Optional<Boiler> bo = boilerRepo.findById(boiler.getId());
		if(bo.isEmpty()) {
			throw new Exception("Boiler not found");
		}
		
		Optional<User> user = userRepo.findById(boiler.getUserId());
		if(user.isEmpty()) {
			throw new Exception("Boiler's user does not exist");
		}
		
		if(!user.get().getRole().toString().equals("CLIENT") ) {
			throw new Exception("Boiler's user is not a client");
		}
		
		
	     bo.get().setBrand(boiler.getBrand());
	     bo.get().setModel(boiler.getModel());
	     bo.get().setRevisionDate(LocalDate.parse(boiler.getRevisionDate(), DATE_FORMATTER));
	     bo.get().setSerialNumber(boiler.getSerialNumber());
	     bo.get().setUser(user.get());
	    
		try {
			boilerRepo.save(bo.get());
		}catch(Exception e) {
			throw new Exception("Error in Boiler Update");
		}
	}
	
	
	
	@Transactional
	public void deleteBoiler(BoilerDto boiler) throws Exception{
		Optional<Boiler> boil = boilerRepo.findById(boiler.getId());
		if(boil.isEmpty()) {
			throw new Exception("Boiler not found");
		}
		boilerRepo.delete(boil.get());
	}
	
}
