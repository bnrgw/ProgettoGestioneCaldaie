package com.gestionale.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionale.backend.dtos.BoilerDto;
import com.gestionale.backend.dtos.TicketDto;
import com.gestionale.backend.dtos.UserDto;
import com.gestionale.backend.response.Response;
import com.gestionale.backend.response.ResponseBase;
import com.gestionale.backend.services.UserService;

@RestController
@RequestMapping("/rest/user")
public class UserController {
 
	@Autowired 
	UserService userSer;
	
	@PostMapping("/create")
	public ResponseBase create (@RequestBody (required = true)  UserDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			userSer.createUser(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	@GetMapping("/read")
	public Response<UserDto> read(){
		Response<UserDto> resp = new Response<UserDto>();
		resp.setRc(true);
		resp.setDati(userSer.readUser());
		return resp;
	}
	
	
	@GetMapping("/readBoilers")
	public Response<BoilerDto> readBoilers(Integer id){
		Response<BoilerDto> resp = new Response<BoilerDto>();
		resp.setRc(true);
		try {
			resp.setDati(userSer.readUsersBoilers(id));
		} catch (Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	@GetMapping("/readTickets")
	public Response<TicketDto> readTickets(Integer id){
		Response<TicketDto> resp = new Response<TicketDto>();
		resp.setRc(true);
		try {
			resp.setDati(userSer.readUsersTickets(id));
		} catch (Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	@GetMapping("/readUserId")
	public String readUserId(String fiscalCode) {
		String resp="";
		try {
			userSer.readUserId(fiscalCode);
		}catch(Exception e) {
			resp = e.getMessage();
		}
		return resp;
	}
	
	@PutMapping("/update")
	public ResponseBase update(@RequestBody ( required = true) UserDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			userSer.updateUser(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
	@DeleteMapping("/delete")
	public ResponseBase delete(@RequestBody ( required = true) UserDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			userSer.deleteUser(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
	@PostMapping("/login")
	public String login(@RequestBody ( required = true) UserDto req) {
	
		try {
			  return userSer.authenticate(req);
		}catch(Exception e) {
			return e.getMessage();
		}
		
	}
}
	
