package com.gestionale.backend.dtos;



public class BoilerDto {
	private Integer id;
	private Integer userId;
	private String brand;
	private String model;
	private Long serialNumber;
	private String revisionDate;



	public BoilerDto(Integer id, Integer userId, String brand, String model, Long serialNumber,
			String revisionDate) {
		super();
		this.id = id;
		this.userId = userId;
		this.brand = brand;
		this.model = model;
		this.serialNumber = serialNumber;
		this.revisionDate = revisionDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Long getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(Long serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getRevisionDate() {
		return revisionDate;
	}

	public void setRevisionDate(String revisionDate) {
		this.revisionDate = revisionDate;
	}

}
