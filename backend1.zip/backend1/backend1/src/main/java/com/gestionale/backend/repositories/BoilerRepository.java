package com.gestionale.backend.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gestionale.backend.entities.Boiler;
import com.gestionale.backend.entities.User;



public interface BoilerRepository extends JpaRepository<Boiler ,Integer> {

	List<Boiler> findByUser(User user);
}
