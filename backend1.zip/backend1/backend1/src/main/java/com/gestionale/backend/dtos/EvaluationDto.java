package com.gestionale.backend.dtos;

public class EvaluationDto {

	private Integer id;
	private Integer ticketId;
	private Integer rating;
	private String note;


	public EvaluationDto(Integer id, Integer ticketId, Integer rating, String note) {
		super();
		this.id = id;
		this.ticketId = ticketId;
		this.rating = rating;
		this.note = note;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTicketId() {
		return ticketId;
	}

	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

}
