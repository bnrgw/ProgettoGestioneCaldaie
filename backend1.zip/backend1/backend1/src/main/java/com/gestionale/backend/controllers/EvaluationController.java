package com.gestionale.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionale.backend.dtos.EvaluationDto;
import com.gestionale.backend.response.Response;
import com.gestionale.backend.response.ResponseBase;
import com.gestionale.backend.services.EvaluationService;


@RestController
@RequestMapping("/rest/evaluation")
public class EvaluationController {

	@Autowired
	EvaluationService evalSer;
	
	@PostMapping("/create")
	public ResponseBase create (@RequestBody (required = true)  EvaluationDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			evalSer.createEvaluation(req);
		}catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
		
		}
	
	
	@GetMapping("/read")
	public Response<EvaluationDto> read(){
		Response<EvaluationDto> resp = new Response<EvaluationDto>();
		resp.setRc(true);
		resp.setDati(evalSer.readEvaluation());
		return resp;
	}
	
	
	@PutMapping("/update")
	public ResponseBase update(@RequestBody ( required = true) EvaluationDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			evalSer.updateEvaluation(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
	@DeleteMapping("/delete")
	public ResponseBase delete(@RequestBody ( required = true) EvaluationDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			evalSer.deleteEvaluation(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
}
