package com.gestionale.backend.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gestionale.backend.entities.Evaluation;


public interface EvaluationRepository extends JpaRepository<Evaluation ,Integer>{

}
