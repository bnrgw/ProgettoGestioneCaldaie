package com.gestionale.backend.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionale.backend.dtos.BoilerDto;
import com.gestionale.backend.dtos.TicketDto;
import com.gestionale.backend.dtos.UserDto;
import com.gestionale.backend.entities.User;
import com.gestionale.backend.entities.Boiler;
import com.gestionale.backend.entities.Ticket;
import com.gestionale.backend.repositories.BoilerRepository;
import com.gestionale.backend.repositories.TicketRepository;
import com.gestionale.backend.repositories.UserRepository;
import com.gestionale.backend.utils.Role;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;


@SuppressWarnings("static-access")
@Service
public class UserService {

	@Autowired
	UserRepository userRepo;

	@Autowired
	BoilerRepository boilerRepo;

	@Autowired
	TicketRepository ticketRepo;

	@SuppressWarnings("deprecation")
	private static final SecretKey SECRET_KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);

	@Transactional
	public void createUser(UserDto user) throws Exception {
		User us = new User();
		us.setName(user.getName());
		us.setSurname(user.getSurname());
		us.setFiscalCode(user.getFiscaleCode());
		us.setAddress(user.getAddress());
		us.setCap(user.getCap());
		us.setCity(user.getCity());
		us.setProvince(user.getProvince());
		us.setPasword(user.getPassword());
		us.setRole(us.getRole().valueOf(user.getRole()));
		

		try {
			userRepo.save(us);
		} catch (Exception e) {
			throw new Exception("Error in User creation");
		}
	}

	public List<UserDto> readUser() {
		List<User> resp = userRepo.findAll();

		return resp.stream()
				.map(u -> new UserDto(u.getId(), u.getName(), u.getSurname(), u.getFiscalCode(), u.getAddress(),
						u.getCap(), u.getCity(), u.getProvince(), u.getPasword(), u.getRole().toString()))
				.collect(Collectors.toList());

	}

	public List<BoilerDto> readUsersBoilers(Integer userId) throws Exception {

		Optional<User> user = userRepo.findById(userId);
		if (user.isEmpty()) {
			throw new Exception("User does not exist");
		}
		List<Boiler> boilers = boilerRepo.findByUser(user.get());

		return boilers.stream().map(s -> new BoilerDto(s.getId(), s.getUser().getId(), s.getBrand(), s.getModel(),
				s.getSerialNumber(), s.getRevisionDate().toString())).collect(Collectors.toList());
	}
 
	public String readUserId(String fc) throws Exception {

		Optional<User> user = userRepo.findByFiscalCode(fc);
		if (user.isEmpty()) {
			throw new Exception("User does not exist");
		}
		return user.get().getId().toString();
	}
	
	
	public List<TicketDto> readUsersTickets(Integer userId) throws Exception {

		Optional<User> user = userRepo.findById(userId);
		if (user.isEmpty()) {
			throw new Exception("User does not exist");
		}

		List<Ticket> tickets = ticketRepo.findByUser(user.get());
		List<TicketDto> listTicket = new ArrayList<TicketDto>();

		for (Ticket t : tickets) {
			if (t.getEvaluation() != null) {

				listTicket.add(new TicketDto(t.getId(), t.getUser().getId(), t.getText(), t.getResponse(), t.getState(),
						t.getEvaluation().getId(), t.getPreferredDate()));
			}

			else {
				listTicket.add(new TicketDto(t.getId(), t.getUser().getId(), t.getText(), t.getResponse(), t.getState(),
						t.getPreferredDate()));
			}
		}

		return listTicket;
	}

	@Transactional
	public void updateUser(UserDto user) throws Exception {
		Optional<User> us = userRepo.findById(user.getId());
		if (us.isEmpty()) {
			throw new Exception("User not found");
		}
		us.get().setName(user.getName());
		us.get().setSurname(user.getSurname());
		us.get().setFiscalCode(user.getFiscaleCode());
		us.get().setAddress(user.getAddress());
		us.get().setCap(user.getCap());
		us.get().setCity(user.getCity());
		us.get().setProvince(user.getProvince());
		us.get().setPasword(user.getPassword());
		us.get().setRole(user.getRole().equals(Role.ADMIN) ? Role.ADMIN : Role.CLIENT);
		
		try {
			userRepo.save(us.get());
		} catch (Exception e) {
			throw new Exception("Error in User Update");
		}
	}

	@Transactional
	public void deleteUser(UserDto user) throws Exception {
		Optional<User> us = userRepo.findById(user.getId());
		if (us.isEmpty()) {
			throw new Exception("User not found");
		}
		userRepo.delete(us.get());
	}
	/*
	 * public String authenticate(UserDto user) throws Exception{ Optional<User> us
	 * = userRepo.findByFiscalCode(user.getFiscaleCode()); /* if(us.isEmpty()) {
	 * throw new Exception("User's fiscalCode or password not correct"); }
	 */
	/*
	 * if(!user.getPassword().equals(us.get().getPasword())) { throw new
	 * Exception("User's fiscalCode or password not correct"); }
	 * 
	 * long now = System.currentTimeMillis(); KeyGenerator keyGenerator =
	 * KeyGenerator.getInstance("HmacSHA256"); keyGenerator.init(256); // 256 bits
	 * for HS256 SecretKey secretKey = keyGenerator.generateKey();
	 * 
	 * JwtBuilder builder = Jwts.builder() .setIssuedAt(new Date(now))
	 * .setSubject(user.getFiscaleCode()) .claim("name", us.get().getName())
	 * .claim("surname", us.get().getSurname()) .claim("city", us.get().getCity())
	 * .setExpiration(new Date(now + 86400000)) .signWith(secretKey);
	 * 
	 * return builder.compact();
	 * 
	 * 
	 * 
	 * 
	 * }
	 */

	public String authenticate(UserDto req) {
		// Validate the user's fiscalCode and password
		boolean isValidUser = validateUser(req.getFiscaleCode(), req.getPassword());

		if (!isValidUser) {
			throw new RuntimeException("Invalid credentials");
		}

		// Generate and return the JWT token if authentication is successful
		  Optional<User> user =userRepo.findByFiscalCode(req.getFiscaleCode());
		return user.get().getId().toString();
	}

	private boolean validateUser(String fiscalCode, String password) {
		Optional<User> us = userRepo.findByFiscalCode(fiscalCode);
		return password.equals(us.get().getPasword());
	}

	private String generateJwtToken(String fiscalCode) {
		long now = System.currentTimeMillis();
		Date expirationDate = new Date(now + 3600000); // Token expires in 1 hour

		// Build the JWT token
		return Jwts.builder().setSubject(fiscalCode) // The user identifier (fiscalCode)
				.setIssuedAt(new Date(now)) // Issue time
				.setExpiration(expirationDate) // Expiry time
				.signWith(SECRET_KEY) // Sign the JWT with the secret key
				.compact(); // Generate the token string
	}
}
