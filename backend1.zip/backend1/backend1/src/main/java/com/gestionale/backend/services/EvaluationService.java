package com.gestionale.backend.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionale.backend.dtos.EvaluationDto;
import com.gestionale.backend.dtos.TicketDto;
import com.gestionale.backend.entities.Evaluation;
import com.gestionale.backend.entities.Ticket;
import com.gestionale.backend.repositories.EvaluationRepository;
import com.gestionale.backend.repositories.TicketRepository;

@Service
public class EvaluationService {

	@Autowired
	EvaluationRepository evalRepo;

	@Autowired
	TicketRepository ticketRepo;

	public void createEvaluation(EvaluationDto evaluation) throws Exception {
		Optional<Ticket> ticket = ticketRepo.findById(evaluation.getTicketId());
		if (ticket.isEmpty()) {
			throw new Exception("Evaluation's ticket does not exist");
		}
		if (ticket.get().getState() == false) {
			throw new Exception("Evaluation's ticket's state must be true or set to 'Done'");
		}
		Evaluation eval = new Evaluation();
		eval.setNote(evaluation.getNote());
		eval.setRating(evaluation.getRating());
		eval.setTicketId(ticket.get());

		evalRepo.save(eval);
	}

	public List<EvaluationDto> readEvaluation() {
		List<Evaluation> resp = evalRepo.findAll();

		return resp.stream().map(u -> new EvaluationDto(u.getId(), u.getTicketId().getId(), u.getRating(), u.getNote()))
				.collect(Collectors.toList());
	}

	@Transactional
	public void updateEvaluation(EvaluationDto evaluation) throws Exception {
		Optional<Evaluation> e = evalRepo.findById(evaluation.getId());
		if (e.isEmpty()) {
			throw new Exception("Evaluation not found");
		}

		Optional<Ticket> ticket = ticketRepo.findById(evaluation.getTicketId());
		if (ticket.isEmpty()) {
			throw new Exception("Evaluation's ticket does not exist");
		}
        
		e.get().setNote(evaluation.getNote());
		e.get().setRating(evaluation.getRating());
		e.get().setTicketId(ticket.get());

		evalRepo.save(e.get());
	}

	@Transactional
	public void deleteEvaluation(EvaluationDto eval) throws Exception {
		Optional<Evaluation> tick = evalRepo.findById(eval.getId());
		if (tick.isEmpty()) {
			throw new Exception("Evaluation not found");
		}
		evalRepo.delete(tick.get());
	}

}
