package com.gestionale.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionale.backend.dtos.BoilerDto;
import com.gestionale.backend.response.Response;
import com.gestionale.backend.response.ResponseBase;
import com.gestionale.backend.services.BoilerService;

@RestController
@RequestMapping("/rest/boiler")
public class BoilerController {

	@Autowired
	BoilerService boilerSer;
	
	@PostMapping("/create")
	public ResponseBase create (@RequestBody (required = true)  BoilerDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			boilerSer.createBoiler(req);
		}catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
		
		}
	
	@GetMapping("/read")
	public Response<BoilerDto> read(){
		Response<BoilerDto> resp = new Response<BoilerDto>();
		resp.setRc(true);
		resp.setDati(boilerSer.readBoiler());
		return resp;
	}
	
	
	@PutMapping("/update")
	public ResponseBase update(@RequestBody (required = true) BoilerDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			boilerSer.updateBoiler(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
	@DeleteMapping("/delete")
	public ResponseBase delete(@RequestBody ( required = true) BoilerDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			boilerSer.deleteBoiler(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
}
