package com.gestionale.backend.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gestionale.backend.entities.Ticket;
import com.gestionale.backend.entities.User;


public interface TicketRepository extends JpaRepository<Ticket ,Integer>{

	List<Ticket> findByUser(User user);
}
