package com.gestionale.backend.utils;

public enum Role {

	CLIENT("client"), ADMIN("admin");

	private final String value;

	Role(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
}
