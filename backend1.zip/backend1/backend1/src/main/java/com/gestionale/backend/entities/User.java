package com.gestionale.backend.entities;

import java.util.List;

import com.gestionale.backend.utils.Role;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "Users", uniqueConstraints = { @UniqueConstraint(columnNames = { "fiscalCode","password" }) })
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "name")
	private String name;

	@Column(name = "surname")
	private String surname;
	
	@Column(name = "fiscalCode")
	private String fiscalCode;

	@Column(name = "address")
	private String address;

	@Column(name = "cap")
	private String cap;

	@Column(name = "city")
	private String city;

	@Column(name = "province")
	private String province;

	@Column(name = "password")
	private String pasword;

	@Column(name = "role")
	private Role role;

	@OneToMany(mappedBy = "user", fetch = FetchType.EAGER,
			cascade = CascadeType.REMOVE)
	private List<Boiler> boilers;

	@OneToMany(mappedBy = "user" , fetch = FetchType.EAGER,
			cascade = CascadeType.REMOVE)
	private List<Ticket> tickets;
	
	

	public User() {
		super();
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public List<Boiler> getBoilers() {
		return boilers;
	}

	public void setBoilers(List<Boiler> boilers) {
		this.boilers = boilers;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFiscalCode() {
		return fiscalCode;
	}

	public void setFiscalCode(String fiscalCode) {
		this.fiscalCode = fiscalCode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCap() {
		return cap;
	}

	public void setCap(String cap) {
		this.cap = cap;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPasword() {
		return pasword;
	}

	public void setPasword(String pasword) {
		this.pasword = pasword;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	

}
