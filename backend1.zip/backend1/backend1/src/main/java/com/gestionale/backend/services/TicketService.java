package com.gestionale.backend.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gestionale.backend.dtos.BoilerDto;
import com.gestionale.backend.dtos.TicketDto;
import com.gestionale.backend.entities.Boiler;
import com.gestionale.backend.entities.Evaluation;
import com.gestionale.backend.entities.Ticket;
import com.gestionale.backend.entities.User;
import com.gestionale.backend.repositories.BoilerRepository;
import com.gestionale.backend.repositories.EvaluationRepository;
import com.gestionale.backend.repositories.TicketRepository;
import com.gestionale.backend.repositories.UserRepository;

@Service
public class TicketService {
	@Autowired
	TicketRepository ticketRepo;

	@Autowired
	UserRepository userRepo;

	@Autowired
	EvaluationRepository evalRepo;

	@Transactional
	public void createTicket(TicketDto ticket) throws Exception {

		Optional<User> user = userRepo.findById(ticket.getUserId());
		if (user.isEmpty()) {
			throw new Exception("Ticket's user does not exist");
		}

		if (user.get().getRole().toString() != "CLIENT") {
			throw new Exception("Ticket's user is not a client");
		}

		Ticket ti = new Ticket();
		ti.setText(ticket.getText());
		ti.setUser(user.get());
		ti.setState(ticket.getState());
		ti.setPreferredDate(ticket.getPreferredDate());

		try {
			ticketRepo.save(ti);
		} catch (Exception e) {
			throw new Exception("Error in ticket creation");
		}
	}

	public List<TicketDto> readTicket() {
		List<Ticket> resp = ticketRepo.findAll();

		return resp.stream().map(u -> new TicketDto(u.getId(), u.getUser().getId(), u.getText(), u.getResponse(),
				u.getState(), u.getEvaluation().getId(), u.getPreferredDate())).collect(Collectors.toList());
	}

	@Transactional
	public void updateTicket(TicketDto ticket) throws Exception {
		Optional<Ticket> ti = ticketRepo.findById(ticket.getId());
		if (ti.isEmpty()) {
			throw new Exception("Ticket not found");
		}

		Optional<User> user = userRepo.findById(ticket.getUserId());
		if (user.isEmpty()) {
			throw new Exception("Ticket's user does not exist");
		}

		if (!user.get().getRole().toString().equals("CLIENT")) {
			throw new Exception("Ticket's user is not a client");
		}

		if (ticket.getEvaluationId() != null) {
			Optional<Evaluation> evaluation = evalRepo.findById(ticket.getEvaluationId());

			if (evaluation.isEmpty()) {
				throw new Exception("Ticket's evaluation does not exist");
			}
			ti.get().setEvaluation(evaluation.get());
		}
		ti.get().setPreferredDate(ticket.getPreferredDate());
		ti.get().setState(ticket.getState());
		ti.get().setResponse(ticket.getResponse());
		ti.get().setText(ticket.getText());
		ti.get().setUser(user.get());

		try {
			ticketRepo.save(ti.get());
		} catch (Exception e) {
			throw new Exception("Error in Ticket Update");
		}
	}

	@Transactional
	public void deleteTicket(TicketDto ticket) throws Exception {
		Optional<Ticket> tick = ticketRepo.findById(ticket.getId());
		if (tick.isEmpty()) {
			throw new Exception("Ticket not found");
		}
		ticketRepo.delete(tick.get());
	}

}
