package com.gestionale.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestionale.backend.dtos.TicketDto;
import com.gestionale.backend.response.Response;
import com.gestionale.backend.response.ResponseBase;
import com.gestionale.backend.services.TicketService;

@RestController
@RequestMapping("/rest/ticket")
public class TicketController {

	@Autowired
	TicketService ticketSer;
	
	@PostMapping("/create")
	public ResponseBase create (@RequestBody (required = true)  TicketDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			ticketSer.createTicket(req);
		}catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
		
		}
	
	
	@GetMapping("/read")
	public Response<TicketDto> read(){
		Response<TicketDto> resp = new Response<TicketDto>();
		resp.setRc(true);
		resp.setDati(ticketSer.readTicket());
		return resp;
	}
	
	
	@PutMapping("/update")
	public ResponseBase update(@RequestBody ( required = true) TicketDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			ticketSer.updateTicket(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
	@DeleteMapping("/delete")
	public ResponseBase delete(@RequestBody ( required = true) TicketDto req) {
		ResponseBase resp = new ResponseBase();
		resp.setRc(true);
		try {
			ticketSer.deleteTicket(req);
		} catch(Exception e) {
			resp.setRc(false);
			resp.setMsg(e.getMessage());
		}
		return resp;
	}
	
	
}
