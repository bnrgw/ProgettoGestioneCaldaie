package com.gestionale.backend.dtos;

import java.util.List;

public class UserDto {
	private Integer id;
	private String name;
	private String surname;
	private String fiscaleCode;
	private String Address;
	private String cap;
	private String city;
	private String province;
	private String password;
	private String role;
	private List<BoilerDto> boilers;
	private List<TicketDto> tickets;
  
	

	public UserDto() {
		super();
	}

	public UserDto(Integer id, String name, String surname, String fiscaleCode, String address, String cap, String city,
			String province, String password, String role) {
		super();
		this.id = id;
		this.name = name;
		this.surname = surname;
		this.fiscaleCode = fiscaleCode;
		Address = address;
		this.cap = cap;
		this.city = city;
		this.province = province;
		this.password = password;
		this.role = role;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFiscaleCode() {
		return fiscaleCode;
	}

	public void setFiscaleCode(String fiscaleCode) {
		this.fiscaleCode = fiscaleCode;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getCap() {
		return cap;
	}

	public void setCap(String cap) {
		this.cap = cap;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<BoilerDto> getBoilers() {
		return boilers;
	}

	public void setBoilers(List<BoilerDto> boilers) {
		this.boilers = boilers;
	}

	public List<TicketDto> getTickets() {
		return tickets;
	}

	public void setTickets(List<TicketDto> tickets) {
		this.tickets = tickets;
	}

}
